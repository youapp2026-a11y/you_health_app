# Blueprint

## Overview

This is a Flutter application that will allow users to chat with a Gemini-powered AI.

## Features Implemented

* Basic Flutter application structure.
* Navigation using `go_router`.
* Placeholder for the chat screen.

## Current Goal: Implement Chat Feature

### Plan

1.  **Create `lib/models/chat_message.dart`:** A model to represent a chat message, with properties for the text and the sender (user or AI).
2.  **Create `lib/providers/chat_provider.dart`:** A provider to manage the state of the chat, including the list of messages and the loading state. This will also handle the logic for sending a message to the Gemini API and receiving a response.
3.  **Update `lib/screens/chat_screen.dart`:** A screen that displays the chat messages and allows the user to send new messages.
4.  **Integrate with Gemini:** Use the `firebase_ai` package to connect to the Gemini API and generate responses.

### Code

**`lib/models/chat_message.dart`**

```dart
enum ChatMessageType {
  user,
  ai,
}

class ChatMessage {
  final String text;
  final ChatMessageType type;

  ChatMessage({required this.text, required this.type});
}
```

**`lib/providers/chat_provider.dart`**

```dart
import 'package:flutter/material.dart';
import 'package:firebase_ai/firebase_ai.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:myapp/models/chat_message.dart';

class ChatProvider with ChangeNotifier {
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;

  List<ChatMessage> get messages => _messages;
  bool get isLoading => _isLoading;

  // Define the model initialization
  final GenerativeModel _model = FirebaseAI.vertexAI(
    auth: FirebaseAuth.instance,
  ).generativeModel(
    model: 'gemini-2.5-pro', // Use the updated model name
  );

  Future<void> sendMessage(String text) async {
    _messages.add(ChatMessage(text: text, type: ChatMessageType.user));
    _isLoading = true;
    notifyListeners();

    try {
      // Use the pre-initialized model
      final response = await _model.generateContent([Content.text(text)]);

      if (response.text != null) {
        _messages.add(ChatMessage(text: response.text!, type: ChatMessageType.ai));
      } else {
        _messages.add(ChatMessage(text: 'No response from model.', type: ChatMessageType.ai));
      }
    } catch (e) {
      _messages.add(ChatMessage(text: 'Error: ${e.toString()}', type: ChatMessageType.ai));
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
```

**`lib/screens/chat_screen.dart`**

```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:myapp/providers/chat_provider.dart';
import 'package:myapp/models/chat_message.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final chatProvider = Provider.of<ChatProvider>(context);
    final TextEditingController controller = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gemini Chat'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: chatProvider.messages.length,
              itemBuilder: (context, index) {
                final message = chatProvider.messages[index];
                return ListTile(
                  title: Text(message.text),
                  leading: message.type == ChatMessageType.user
                      ? const Icon(Icons.person)
                      : const Icon(Icons.computer),
                );
              },
            ),
          ),
          if (chatProvider.isLoading)
            const CircularProgressIndicator(),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    decoration: const InputDecoration(
                      hintText: 'Type a message',
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: () {
                    if (controller.text.isNotEmpty) {
                      chatProvider.sendMessage(controller.text);
                      controller.clear();
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
```

import 'package:flutter/material.dart';
import 'package:firebase_ai/firebase_ai.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:myapp/models/chat_message.dart';

class ChatProvider with ChangeNotifier {
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;

  List<ChatMessage> get messages => _messages;
  bool get isLoading => _isLoading;

  // Define the model initialization
  final GenerativeModel _model = FirebaseAI.vertexAI(
    auth: FirebaseAuth.instance,
  ).generativeModel(
    model: 'gemini-2.5-pro', // Use the updated model name
  );

  Future<void> sendMessage(String text) async {
    _messages.add(ChatMessage(text: text, type: ChatMessageType.user));
    _isLoading = true;
    notifyListeners();

    try {
      // Use the pre-initialized model
      final response = await _model.generateContent([Content.text(text)]);

      if (response.text != null) {
        _messages.add(ChatMessage(text: response.text!, type: ChatMessageType.ai));
      } else {
        _messages.add(ChatMessage(text: 'No response from model.', type: ChatMessageType.ai));
      }
    } catch (e) {
      _messages.add(ChatMessage(text: 'Error: ${e.toString()}', type: ChatMessageType.ai));
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
